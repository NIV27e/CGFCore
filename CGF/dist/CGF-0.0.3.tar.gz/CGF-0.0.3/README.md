from CGF.CGFCore import main
from CGF.test import evaluate

# main.test_composed_game_sequential()

evaluate.run_tests()
